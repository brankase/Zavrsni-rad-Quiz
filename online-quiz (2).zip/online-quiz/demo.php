<?php
include 'header.php';
?>


        <div class="row" style="margin: 0px; padding:0px; margin-bottom: 50px;">

            <div class="col-lg-6 col-lg-push-3" style="min-height: 500px; background-color: white;"></div>

        </div>




  <?php
  include 'footer.php';
  ?>